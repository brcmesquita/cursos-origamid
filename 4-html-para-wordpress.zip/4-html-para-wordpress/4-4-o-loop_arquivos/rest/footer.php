		<footer>
			<nav class="nav-footer">
				<ul>
					<li class="current_page_item"><a href="/testewp/">Menu</a></li>
					<li><a href="/testewp/sobre/">Sobre</a></li>
					<li><a href="/testewp/contato/">Contato</a></li>
				</ul>
			</nav>

			<p>Rest © 2015. Alguns direitos reservados.</p>
		</footer>

		<!-- Footer Wordpress -->
		<?php wp_footer(); ?>
		<!-- Fecha Footer Wordpress -->
	</body>
</html>